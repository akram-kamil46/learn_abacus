
  # Responsive Abacus Learning Website

  This is a code bundle for Responsive Abacus Learning Website. The original project is available at https://www.figma.com/design/guHEZo1In1cjeTThCD1QFe/Responsive-Abacus-Learning-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  