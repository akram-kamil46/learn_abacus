import { Brain, Zap, Target, TrendingUp, Focus, Calculator } from "lucide-react";

export function Benefits() {
  const benefits = [
    {
      icon: Calculator,
      title: "Faster Calculations",
      description: "Develops the ability to perform complex arithmetic operations quickly and accurately in your mind.",
    },
    {
      icon: Brain,
      title: "Improved Memory",
      description: "Enhances both short-term and long-term memory through visualization and mental calculation practice.",
    },
    {
      icon: Focus,
      title: "Better Concentration",
      description: "Trains the mind to focus deeply on tasks, improving attention span and reducing distractions.",
    },
    {
      icon: TrendingUp,
      title: "Logical Thinking",
      description: "Strengthens analytical and problem-solving skills by understanding number relationships and patterns.",
    },
    {
      icon: Target,
      title: "Enhanced Accuracy",
      description: "Reduces calculation errors through systematic mental processing and verification techniques.",
    },
    {
      icon: Zap,
      title: "Cognitive Development",
      description: "Stimulates both brain hemispheres, promoting overall cognitive growth and academic performance.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Benefits of Abacus Learning</h2>
        <p className="text-lg text-gray-600 mb-12 text-center max-w-3xl mx-auto">
          Learning abacus provides numerous cognitive benefits that extend far beyond mathematics, 
          helping learners of all ages improve their mental abilities.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="bg-gray-50 p-6 rounded-lg border border-gray-200 hover:border-blue-300 transition-colors"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="text-blue-600" size={24} />
                </div>
                <h3 className="text-xl mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-blue-50 border border-blue-200 rounded-lg p-8 max-w-3xl mx-auto">
          <h3 className="text-xl mb-4">Research-Backed Results</h3>
          <p className="text-gray-700 mb-4">
            Studies have shown that children who learn abacus demonstrate significant improvements in:
          </p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">✓</span>
              <span>Mathematical competency and number sense</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">✓</span>
              <span>Visual-spatial reasoning and mental imagery</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">✓</span>
              <span>Working memory capacity and processing speed</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">✓</span>
              <span>Academic performance across multiple subjects</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
