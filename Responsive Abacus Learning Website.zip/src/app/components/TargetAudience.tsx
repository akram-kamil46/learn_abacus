import { Users, GraduationCap, Heart } from "lucide-react";

export function TargetAudience() {
  const audiences = [
    {
      icon: Users,
      title: "Children (Ages 5-14)",
      description: "Ideal age to start learning abacus. Develops foundational math skills, improves concentration, and builds confidence in problem-solving.",
      howToUse: [
        "Start with beginner modules to understand number formation",
        "Use the interactive simulator to practice moving beads",
        "Complete daily exercises for 15-20 minutes",
        "Progress gradually from simple to complex operations",
      ],
    },
    {
      icon: Heart,
      title: "Parents",
      description: "Support your child's learning journey and understand how abacus training enhances cognitive development and academic performance.",
      howToUse: [
        "Review learning modules to understand the methodology",
        "Monitor your child's progress through practice sections",
        "Download worksheets for offline practice sessions",
        "Use resources to create a structured learning schedule",
      ],
    },
    {
      icon: GraduationCap,
      title: "Teachers & Educators",
      description: "Integrate abacus training into your curriculum. Access structured lessons, practice materials, and teaching resources.",
      howToUse: [
        "Follow the structured learning path for classroom instruction",
        "Download printable worksheets and practice materials",
        "Use the simulator for interactive classroom demonstrations",
        "Assign practice exercises as homework or in-class activities",
      ],
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Who Can Learn?</h2>
        <p className="text-lg text-gray-600 mb-12 text-center max-w-3xl mx-auto">
          Our platform is designed to serve learners, parents, and educators with tailored resources for each group.
        </p>

        <div className="grid lg:grid-cols-3 gap-8">
          {audiences.map((audience, index) => {
            const Icon = audience.icon;
            return (
              <div key={index} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="bg-blue-600 text-white p-6">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                    <Icon size={24} />
                  </div>
                  <h3 className="text-xl">{audience.title}</h3>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-6">{audience.description}</p>
                  <h4 className="font-semibold mb-3">How to Use This Platform:</h4>
                  <ul className="space-y-2">
                    {audience.howToUse.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-gray-600">
                        <span className="text-blue-600 mt-1">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
