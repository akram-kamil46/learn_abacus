import { useState, useEffect } from "react";
import { Play, Check, X, Trophy, Clock, RotateCcw } from "lucide-react";

interface Question {
  question: string;
  answer: number;
  operation: string;
}

export function PracticeExercises() {
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("easy");
  const [mode, setMode] = useState<"timed" | "untimed">("untimed");
  const [isActive, setIsActive] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [timeLeft, setTimeLeft] = useState(60);
  const [showResults, setShowResults] = useState(false);
  const [answeredQuestions, setAnsweredQuestions] = useState(0);

  // Timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isActive && mode === "timed" && timeLeft > 0 && !showResults) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            endQuiz();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isActive, mode, timeLeft, showResults]);

  const generateQuestions = (diff: "easy" | "medium" | "hard") => {
    const questionCount = 10;
    const newQuestions: Question[] = [];

    for (let i = 0; i < questionCount; i++) {
      let num1: number, num2: number, operation: string, answer: number;

      switch (diff) {
        case "easy":
          num1 = Math.floor(Math.random() * 20) + 1;
          num2 = Math.floor(Math.random() * 20) + 1;
          operation = Math.random() > 0.5 ? "+" : "-";
          if (operation === "-" && num1 < num2) {
            [num1, num2] = [num2, num1]; // Ensure positive result
          }
          answer = operation === "+" ? num1 + num2 : num1 - num2;
          break;

        case "medium":
          num1 = Math.floor(Math.random() * 50) + 10;
          num2 = Math.floor(Math.random() * 50) + 10;
          const ops = ["+", "-"];
          operation = ops[Math.floor(Math.random() * ops.length)];
          if (operation === "-" && num1 < num2) {
            [num1, num2] = [num2, num1];
          }
          answer = operation === "+" ? num1 + num2 : num1 - num2;
          break;

        case "hard":
          num1 = Math.floor(Math.random() * 100) + 10;
          num2 = Math.floor(Math.random() * 100) + 10;
          const hardOps = ["+", "-", "×"];
          operation = hardOps[Math.floor(Math.random() * hardOps.length)];
          if (operation === "-" && num1 < num2) {
            [num1, num2] = [num2, num1];
          }
          if (operation === "×") {
            num1 = Math.floor(Math.random() * 20) + 2;
            num2 = Math.floor(Math.random() * 20) + 2;
          }
          answer = operation === "+" ? num1 + num2 : operation === "-" ? num1 - num2 : num1 * num2;
          break;
      }

      newQuestions.push({
        question: `${num1} ${operation} ${num2}`,
        answer: answer!,
        operation: operation!,
      });
    }

    return newQuestions;
  };

  const startQuiz = () => {
    const newQuestions = generateQuestions(difficulty);
    setQuestions(newQuestions);
    setCurrentQuestionIndex(0);
    setScore(0);
    setAnsweredQuestions(0);
    setUserAnswer("");
    setFeedback(null);
    setIsActive(true);
    setShowResults(false);
    setTimeLeft(mode === "timed" ? 60 : 0);
  };

  const submitAnswer = () => {
    if (userAnswer === "") return;

    const currentQuestion = questions[currentQuestionIndex];
    const isCorrect = parseInt(userAnswer) === currentQuestion.answer;

    setFeedback(isCorrect ? "correct" : "incorrect");
    if (isCorrect) {
      setScore(score + 1);
    }
    setAnsweredQuestions(answeredQuestions + 1);

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setUserAnswer("");
        setFeedback(null);
      } else {
        endQuiz();
      }
    }, 1000);
  };

  const endQuiz = () => {
    setIsActive(false);
    setShowResults(true);
  };

  const resetQuiz = () => {
    setIsActive(false);
    setShowResults(false);
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setUserAnswer("");
    setScore(0);
    setAnsweredQuestions(0);
    setFeedback(null);
    setTimeLeft(60);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !feedback) {
      submitAnswer();
    }
  };

  const currentQuestion = questions[currentQuestionIndex];
  const percentage = answeredQuestions > 0 ? Math.round((score / answeredQuestions) * 100) : 0;

  return (
    <section id="practice" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Practice Exercises</h2>
        <p className="text-lg text-gray-600 mb-12 text-center max-w-3xl mx-auto">
          Test your abacus skills with interactive quizzes. Choose your difficulty level and practice mode, 
          then solve problems to improve your mental arithmetic abilities.
        </p>

        <div className="max-w-3xl mx-auto">
          {!isActive && !showResults && (
            <div className="bg-gray-50 rounded-lg border border-gray-200 p-8">
              {/* Difficulty Selection */}
              <div className="mb-8">
                <h3 className="text-xl mb-4">Select Difficulty:</h3>
                <div className="grid grid-cols-3 gap-4">
                  <button
                    onClick={() => setDifficulty("easy")}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      difficulty === "easy"
                        ? "border-blue-600 bg-blue-50"
                        : "border-gray-300 hover:border-blue-400"
                    }`}
                  >
                    <div className="font-semibold mb-1">Easy</div>
                    <div className="text-sm text-gray-600">Numbers 1-20</div>
                    <div className="text-sm text-gray-600">+, -</div>
                  </button>
                  <button
                    onClick={() => setDifficulty("medium")}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      difficulty === "medium"
                        ? "border-blue-600 bg-blue-50"
                        : "border-gray-300 hover:border-blue-400"
                    }`}
                  >
                    <div className="font-semibold mb-1">Medium</div>
                    <div className="text-sm text-gray-600">Numbers 10-60</div>
                    <div className="text-sm text-gray-600">+, -</div>
                  </button>
                  <button
                    onClick={() => setDifficulty("hard")}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      difficulty === "hard"
                        ? "border-blue-600 bg-blue-50"
                        : "border-gray-300 hover:border-blue-400"
                    }`}
                  >
                    <div className="font-semibold mb-1">Hard</div>
                    <div className="text-sm text-gray-600">Numbers 10-100</div>
                    <div className="text-sm text-gray-600">+, -, ×</div>
                  </button>
                </div>
              </div>

              {/* Mode Selection */}
              <div className="mb-8">
                <h3 className="text-xl mb-4">Select Mode:</h3>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setMode("untimed")}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      mode === "untimed"
                        ? "border-blue-600 bg-blue-50"
                        : "border-gray-300 hover:border-blue-400"
                    }`}
                  >
                    <div className="font-semibold mb-1">Untimed</div>
                    <div className="text-sm text-gray-600">Practice at your own pace</div>
                  </button>
                  <button
                    onClick={() => setMode("timed")}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      mode === "timed"
                        ? "border-blue-600 bg-blue-50"
                        : "border-gray-300 hover:border-blue-400"
                    }`}
                  >
                    <div className="font-semibold mb-1">Timed</div>
                    <div className="text-sm text-gray-600">60 seconds challenge</div>
                  </button>
                </div>
              </div>

              <button
                onClick={startQuiz}
                className="w-full bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 text-lg"
              >
                <Play size={24} />
                Start Practice
              </button>
            </div>
          )}

          {isActive && !showResults && currentQuestion && (
            <div className="bg-gray-50 rounded-lg border border-gray-200 p-8">
              {/* Progress and Timer */}
              <div className="flex justify-between items-center mb-6">
                <div className="text-sm text-gray-600">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </div>
                {mode === "timed" && (
                  <div className="flex items-center gap-2 text-lg">
                    <Clock className="text-blue-600" size={20} />
                    <span className={timeLeft <= 10 ? "text-red-600 font-bold" : ""}>
                      {timeLeft}s
                    </span>
                  </div>
                )}
                <div className="text-sm text-gray-600">
                  Score: {score}/{answeredQuestions}
                </div>
              </div>

              {/* Question */}
              <div className="bg-white rounded-lg p-8 mb-6 text-center">
                <div className="text-4xl md:text-5xl mb-6">{currentQuestion.question}</div>
                <input
                  type="number"
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Your answer"
                  disabled={feedback !== null}
                  className="text-3xl text-center w-48 px-4 py-3 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  autoFocus
                />
              </div>

              {/* Feedback */}
              {feedback && (
                <div
                  className={`mb-6 p-4 rounded-lg flex items-center justify-center gap-2 ${
                    feedback === "correct"
                      ? "bg-green-50 border border-green-200 text-green-700"
                      : "bg-red-50 border border-red-200 text-red-700"
                  }`}
                >
                  {feedback === "correct" ? (
                    <>
                      <Check size={24} />
                      <span className="text-lg">Correct!</span>
                    </>
                  ) : (
                    <>
                      <X size={24} />
                      <span className="text-lg">
                        Incorrect. The answer is {currentQuestion.answer}
                      </span>
                    </>
                  )}
                </div>
              )}

              {/* Submit Button */}
              {!feedback && (
                <button
                  onClick={submitAnswer}
                  disabled={userAnswer === ""}
                  className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Submit Answer
                </button>
              )}
            </div>
          )}

          {showResults && (
            <div className="bg-gray-50 rounded-lg border border-gray-200 p-8 text-center">
              <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trophy className="text-yellow-600" size={40} />
              </div>
              <h3 className="text-3xl mb-4">Quiz Complete!</h3>
              <div className="text-6xl mb-2">
                {score}/{questions.length}
              </div>
              <div className="text-xl text-gray-600 mb-8">{percentage}% Correct</div>

              <div className="bg-white rounded-lg p-6 mb-6">
                <h4 className="text-lg mb-4">Performance:</h4>
                <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
                  <div
                    className="bg-blue-600 h-4 rounded-full transition-all"
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
                <p className="text-gray-600">
                  {percentage >= 80
                    ? "Excellent work! Keep practicing to maintain your skills."
                    : percentage >= 60
                    ? "Good effort! A bit more practice will improve your accuracy."
                    : "Keep practicing! Regular practice will help you improve."}
                </p>
              </div>

              <button
                onClick={resetQuiz}
                className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw size={20} />
                Try Again
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
