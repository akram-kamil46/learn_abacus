export function AbacusStructure() {
  const structures = [
    {
      title: "Frame",
      description: "The outer rectangular structure that holds all components together.",
    },
    {
      title: "Rods (Columns)",
      description: "Vertical wires or rods that run through the frame. Each rod represents a place value (ones, tens, hundreds, etc.).",
    },
    {
      title: "Beads",
      description: "Small counting objects that slide along the rods. In a standard soroban: 1 heaven bead (value 5) and 4 earth beads (value 1 each).",
    },
    {
      title: "Bar (Reckoning Bar)",
      description: "The horizontal divider that separates heaven beads from earth beads. Beads touching this bar are 'active' and count toward the number.",
    },
  ];

  const examples = [
    { number: "3", heaven: 0, earth: 3, description: "3 earth beads moved up" },
    { number: "5", heaven: 1, earth: 0, description: "1 heaven bead moved down" },
    { number: "7", heaven: 1, earth: 2, description: "1 heaven bead + 2 earth beads" },
    { number: "9", heaven: 1, earth: 4, description: "1 heaven bead + 4 earth beads" },
  ];

  return (
    <section id="structure" className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Abacus Structure and Working</h2>
        
        <div className="max-w-3xl mx-auto mb-12">
          <p className="text-lg text-gray-600 mb-8 text-center">
            Understanding the basic components of an abacus is essential for learning how to use it effectively.
          </p>
          
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {structures.map((item, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <h4 className="text-xl mb-2">{item.title}</h4>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          <h3 className="text-2xl md:text-3xl mb-6 text-center">How Numbers are Represented</h3>
          <p className="text-gray-600 mb-8 text-center">
            In a Japanese soroban (the most common abacus in education), each rod can represent values from 0 to 9:
          </p>

          <div className="bg-white rounded-lg border border-gray-200 p-8 mb-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {examples.map((example, index) => (
                <div key={index} className="text-center">
                  <div className="mb-4">
                    <div className="inline-block relative">
                      {/* Mini abacus representation */}
                      <div className="w-20 border-2 border-gray-800 rounded p-2">
                        {/* Heaven section */}
                        <div className="border-b-2 border-gray-800 pb-2 mb-2 h-6 flex items-start justify-center">
                          <div className={`w-4 h-4 rounded-full ${example.heaven === 1 ? 'bg-red-500' : 'bg-gray-300'}`}></div>
                        </div>
                        {/* Earth section */}
                        <div className="flex flex-col gap-1 items-center pt-2">
                          {[0, 1, 2, 3].map((i) => (
                            <div
                              key={i}
                              className={`w-4 h-4 rounded-full ${i < example.earth ? 'bg-blue-500' : 'bg-gray-300'}`}
                            ></div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-2xl mb-2">{example.number}</div>
                  <div className="text-sm text-gray-500">{example.description}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h4 className="text-xl mb-4">Key Principles:</h4>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Beads are in "reset" position when heaven beads are away from the bar (up) and earth beads are away from the bar (down)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Move heaven beads DOWN toward the bar to activate them (each = 5)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Move earth beads UP toward the bar to activate them (each = 1)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>The rightmost rod is the ones place, next is tens, then hundreds, and so on</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>To represent larger numbers, use multiple rods reading from left to right</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
