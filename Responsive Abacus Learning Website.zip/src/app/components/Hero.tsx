import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  const scrollToLearn = () => {
    const element = document.getElementById("learn");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="py-16 md:py-24 bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl mb-6">
              Master Mental Arithmetic with Abacus
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              The abacus is an ancient calculating tool that enhances mental math abilities, 
              improves concentration, and develops logical thinking. Learn at your own pace 
              with our interactive lessons and practice tools.
            </p>
            <button
              onClick={scrollToLearn}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Learning
            </button>
          </div>
          <div className="flex justify-center">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1548175551-1edaea7bbf0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYmFjdXMlMjBiZWFkcyUyMGNhbGN1bGF0aW9ufGVufDF8fHx8MTc3MDI3MjQ5Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Abacus beads calculation"
              className="rounded-lg shadow-lg max-w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
