import { ImageWithFallback } from "./figma/ImageWithFallback";

export function AboutAbacus() {
  const abacusTypes = [
    {
      name: "Chinese Abacus (Suanpan)",
      description: "Features 2 beads in the upper deck (heaven) and 5 beads in the lower deck (earth). Each upper bead represents 5 and each lower bead represents 1.",
      image: "https://images.unsplash.com/photo-1548175551-1edaea7bbf0d?w=400",
    },
    {
      name: "Japanese Abacus (Soroban)",
      description: "Modern version with 1 bead in the upper deck and 4 beads in the lower deck. More streamlined and commonly used in abacus education today.",
      image: "https://images.unsplash.com/photo-1548175551-1edaea7bbf0d?w=400",
    },
    {
      name: "Indian Abacus",
      description: "Traditional counting frame used in ancient India. Often has 10 beads per rod, making it ideal for teaching basic number concepts to children.",
      image: "https://images.unsplash.com/photo-1548175551-1edaea7bbf0d?w=400",
    },
  ];

  return (
    <section id="about" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">What is an Abacus?</h2>
        
        <div className="max-w-3xl mx-auto mb-12">
          <p className="text-lg text-gray-600 mb-4">
            An abacus is a manual calculating device that has been used for thousands of years 
            to perform arithmetic operations. It consists of a rectangular frame with rods or 
            wires, along which beads slide.
          </p>
          <p className="text-lg text-gray-600 mb-4">
            The word "abacus" comes from the Greek word "abax," meaning "board" or "tablet." 
            This remarkable tool was invented over 2,000 years ago and is believed to have 
            originated in Mesopotamia around 2400 BCE.
          </p>
          <p className="text-lg text-gray-600">
            The abacus spread across ancient civilizations including China, Japan, Russia, and Rome. 
            Each culture developed its own variation, but the fundamental principle remained the same: 
            representing numbers through bead positions and performing calculations by moving beads.
          </p>
        </div>

        <div className="mb-8">
          <h3 className="text-2xl md:text-3xl mb-8 text-center">Types of Abacus</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {abacusTypes.map((type, index) => (
              <div key={index} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                <ImageWithFallback
                  src={type.image}
                  alt={type.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h4 className="text-xl mb-3">{type.name}</h4>
                  <p className="text-gray-600">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
