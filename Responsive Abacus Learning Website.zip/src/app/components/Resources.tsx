import { Download, FileText, Video, BookOpen } from "lucide-react";

export function Resources() {
  const resources = [
    {
      icon: FileText,
      title: "Beginner Worksheets",
      description: "Number formation practice sheets (1-100)",
      fileType: "PDF",
    },
    {
      icon: FileText,
      title: "Addition Practice",
      description: "Progressive addition exercises with solutions",
      fileType: "PDF",
    },
    {
      icon: FileText,
      title: "Subtraction Practice",
      description: "Subtraction drills from basic to advanced",
      fileType: "PDF",
    },
    {
      icon: FileText,
      title: "Multiplication Tables",
      description: "Abacus-based multiplication reference guide",
      fileType: "PDF",
    },
    {
      icon: BookOpen,
      title: "Complete Study Guide",
      description: "Comprehensive abacus learning manual",
      fileType: "PDF",
    },
    {
      icon: Video,
      title: "Video Tutorials",
      description: "Step-by-step visual learning guides",
      fileType: "Coming Soon",
    },
  ];

  const handleDownload = (title: string) => {
    // In a real application, this would trigger an actual download
    alert(`Download functionality for "${title}" would be implemented in production. This would generate a PDF worksheet based on the resource type.`);
  };

  return (
    <section id="resources" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Learning Resources</h2>
        <p className="text-lg text-gray-600 mb-12 text-center max-w-3xl mx-auto">
          Download printable worksheets, study guides, and practice materials to support your abacus learning journey.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource, index) => {
            const Icon = resource.icon;
            const isComingSoon = resource.fileType === "Coming Soon";
            return (
              <div
                key={index}
                className="bg-gray-50 rounded-lg border border-gray-200 p-6 hover:border-blue-300 transition-colors"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Icon className="text-blue-600" size={20} />
                  </div>
                  <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                    {resource.fileType}
                  </span>
                </div>
                <h3 className="text-lg mb-2">{resource.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{resource.description}</p>
                <button
                  onClick={() => handleDownload(resource.title)}
                  disabled={isComingSoon}
                  className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                    isComingSoon
                      ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                      : "bg-blue-600 text-white hover:bg-blue-700"
                  }`}
                >
                  <Download size={16} />
                  {isComingSoon ? "Coming Soon" : "Download"}
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-blue-50 border border-blue-200 rounded-lg p-6 max-w-3xl mx-auto">
          <h3 className="text-xl mb-3">About These Resources</h3>
          <p className="text-gray-700">
            All resources are designed to complement the online learning experience. 
            Print worksheets for offline practice, use study guides for reference, 
            and follow video tutorials for visual demonstrations. Resources are updated 
            regularly based on learner feedback and educational best practices.
          </p>
        </div>
      </div>
    </section>
  );
}
