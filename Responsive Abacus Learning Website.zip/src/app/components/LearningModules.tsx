import { useState } from "react";
import { ChevronDown, ChevronUp, BookOpen } from "lucide-react";

interface Module {
  title: string;
  lessons: Lesson[];
}

interface Lesson {
  title: string;
  content: string;
  examples: string[];
  tips?: string[];
}

export function LearningModules() {
  const [activeLevel, setActiveLevel] = useState<"beginner" | "intermediate" | "advanced">("beginner");
  const [expandedLesson, setExpandedLesson] = useState<number | null>(null);

  const modules: Record<string, Module> = {
    beginner: {
      title: "Beginner Level",
      lessons: [
        {
          title: "Understanding the Abacus Structure",
          content: "Learn the basic components of the abacus including the frame, rods, beads, and the reckoning bar that separates heaven and earth beads.",
          examples: [
            "The frame holds everything together",
            "Each rod represents a place value (ones, tens, hundreds)",
            "Heaven beads are worth 5 each",
            "Earth beads are worth 1 each",
          ],
          tips: [
            "Start by identifying each component before moving beads",
            "Remember: beads touching the bar are 'active'",
          ],
        },
        {
          title: "Number Formation (0-9)",
          content: "Master representing single-digit numbers on one rod. This is the foundation of all abacus calculations.",
          examples: [
            "0: All beads away from the bar",
            "1-4: Move that many earth beads up",
            "5: Move one heaven bead down",
            "6-9: One heaven bead down + remaining earth beads up",
          ],
          tips: [
            "Practice forming each number slowly and accurately",
            "Say the number out loud as you form it",
            "Reset the rod completely before forming the next number",
          ],
        },
        {
          title: "Two-Digit Numbers",
          content: "Learn to represent numbers from 10 to 99 using two rods. The left rod is tens, the right rod is ones.",
          examples: [
            "23: Left rod shows 2, right rod shows 3",
            "58: Left rod shows 5, right rod shows 8",
            "90: Left rod shows 9, right rod shows 0",
          ],
          tips: [
            "Always start from the leftmost digit",
            "Keep rods separated mentally - each has its own value",
          ],
        },
        {
          title: "Three-Digit Numbers and Beyond",
          content: "Expand your skills to represent hundreds, thousands, and larger numbers using multiple rods.",
          examples: [
            "365: Three rods showing 3, 6, 5 from left to right",
            "1,234: Four rods showing 1, 2, 3, 4",
          ],
          tips: [
            "Use place value labels if you're learning",
            "Practice writing the number before setting it on the abacus",
          ],
        },
      ],
    },
    intermediate: {
      title: "Intermediate Level",
      lessons: [
        {
          title: "Simple Addition (No Carrying)",
          content: "Learn to add numbers without carrying over to the next column. This builds the foundation for more complex addition.",
          examples: [
            "2 + 3 = 5: Start with 2, add 3 more earth beads",
            "4 + 5 = 9: Start with 4, add 1 heaven bead and remove 1 earth bead",
            "11 + 23 = 34: Add ones column (1+3=4), then tens column (1+2=3)",
          ],
          tips: [
            "Always work from right to left (ones, then tens, then hundreds)",
            "Complete each column before moving to the next",
            "Verify your answer by counting the final bead positions",
          ],
        },
        {
          title: "Addition with Carrying",
          content: "Master addition when the sum in a column exceeds 9, requiring you to carry over to the next place value.",
          examples: [
            "7 + 5 = 12: Set 7, add 5 gives 12. Show 2 in ones, carry 1 to tens",
            "28 + 34 = 62: 8+4=12 (carry 1), 2+3+1=6",
            "156 + 78 = 234: Work through each column with carrying",
          ],
          tips: [
            "When a column sums to 10 or more, clear it and add 1 to the left column",
            "Practice small carries before attempting larger problems",
          ],
        },
        {
          title: "Simple Subtraction (No Borrowing)",
          content: "Learn subtraction when each digit being subtracted is smaller than the corresponding digit in the original number.",
          examples: [
            "8 - 3 = 5: Start with 8, remove 3 earth beads",
            "9 - 4 = 5: Start with 9 (1 heaven + 4 earth), remove 4 earth beads",
            "57 - 23 = 34: Subtract ones (7-3=4), then tens (5-2=3)",
          ],
          tips: [
            "Work from right to left, same as addition",
            "Remove beads carefully, ensuring you subtract the correct amount",
          ],
        },
        {
          title: "Subtraction with Borrowing",
          content: "Handle subtraction when you need to borrow from the next higher place value.",
          examples: [
            "12 - 5 = 7: Cannot take 5 from 2, so borrow 1 ten (making 12 in ones), then 12-5=7",
            "54 - 28 = 26: Borrow for ones column, then complete the subtraction",
          ],
          tips: [
            "When you can't subtract from a column, borrow 10 from the left column",
            "Practice borrowing with small numbers first",
          ],
        },
      ],
    },
    advanced: {
      title: "Advanced Level",
      lessons: [
        {
          title: "Introduction to Multiplication",
          content: "Multiplication on an abacus uses repeated addition and specific techniques. Start with single-digit multiplication.",
          examples: [
            "3 × 4 = 12: Add 3 four times (3+3+3+3)",
            "6 × 7 = 42: Use memorized multiplication facts and abacus technique",
            "9 × 8 = 72: Advanced techniques for larger products",
          ],
          tips: [
            "Memorize multiplication tables first",
            "Use the abacus to verify your mental calculations",
            "Practice with multipliers 1-9 before moving to larger numbers",
          ],
        },
        {
          title: "Multi-Digit Multiplication",
          content: "Apply multiplication techniques to problems with multi-digit numbers using partial products.",
          examples: [
            "23 × 4 = 92: (20×4) + (3×4) = 80 + 12",
            "15 × 12 = 180: Break into partial products",
          ],
          tips: [
            "Break the problem into smaller parts",
            "Use extra rods for intermediate calculations",
            "Verify with estimation before calculating",
          ],
        },
        {
          title: "Introduction to Division",
          content: "Division on the abacus uses repeated subtraction and specific algorithms. Begin with simple division.",
          examples: [
            "12 ÷ 3 = 4: Subtract 3 repeatedly until reaching 0 (4 times)",
            "35 ÷ 5 = 7: Count how many times 5 can be subtracted",
          ],
          tips: [
            "Division is the inverse of multiplication",
            "Know your multiplication tables well before attempting division",
            "Use estimation to check if your answer makes sense",
          ],
        },
        {
          title: "Complex Calculations and Mental Math",
          content: "Develop the ability to visualize the abacus mentally and perform calculations without a physical abacus.",
          examples: [
            "Mental visualization: Picture the abacus and move beads in your mind",
            "Speed calculations: Combine multiple operations efficiently",
            "Large number operations: Work with 5-7 digit numbers fluently",
          ],
          tips: [
            "Practice physical abacus first before attempting mental calculations",
            "Start with simple mental calculations and gradually increase difficulty",
            "Regular practice is key to developing mental abacus skills",
            "Aim for accuracy first, then work on speed",
          ],
        },
      ],
    },
  };

  const currentModule = modules[activeLevel];

  const toggleLesson = (index: number) => {
    setExpandedLesson(expandedLesson === index ? null : index);
  };

  return (
    <section id="learn" className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Learning Modules</h2>
        <p className="text-lg text-gray-600 mb-12 text-center max-w-3xl mx-auto">
          Structured lessons from basic number formation to advanced calculations. 
          Follow the progression to build a strong foundation in abacus arithmetic.
        </p>

        {/* Level Tabs */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8 max-w-3xl mx-auto">
          <button
            onClick={() => {
              setActiveLevel("beginner");
              setExpandedLesson(null);
            }}
            className={`flex-1 px-6 py-3 rounded-lg transition-colors ${
              activeLevel === "beginner"
                ? "bg-blue-600 text-white"
                : "bg-white text-gray-700 border border-gray-300 hover:border-blue-400"
            }`}
          >
            <div className="text-lg">Beginner</div>
            <div className="text-sm opacity-90">Number Formation</div>
          </button>
          <button
            onClick={() => {
              setActiveLevel("intermediate");
              setExpandedLesson(null);
            }}
            className={`flex-1 px-6 py-3 rounded-lg transition-colors ${
              activeLevel === "intermediate"
                ? "bg-blue-600 text-white"
                : "bg-white text-gray-700 border border-gray-300 hover:border-blue-400"
            }`}
          >
            <div className="text-lg">Intermediate</div>
            <div className="text-sm opacity-90">Addition & Subtraction</div>
          </button>
          <button
            onClick={() => {
              setActiveLevel("advanced");
              setExpandedLesson(null);
            }}
            className={`flex-1 px-6 py-3 rounded-lg transition-colors ${
              activeLevel === "advanced"
                ? "bg-blue-600 text-white"
                : "bg-white text-gray-700 border border-gray-300 hover:border-blue-400"
            }`}
          >
            <div className="text-lg">Advanced</div>
            <div className="text-sm opacity-90">Multiplication & Division</div>
          </button>
        </div>

        {/* Lessons */}
        <div className="max-w-4xl mx-auto">
          <div className="space-y-4">
            {currentModule.lessons.map((lesson, index) => (
              <div
                key={index}
                className="bg-white rounded-lg border border-gray-200 overflow-hidden"
              >
                <button
                  onClick={() => toggleLesson(index)}
                  className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded flex items-center justify-center flex-shrink-0">
                      <BookOpen className="text-blue-600" size={18} />
                    </div>
                    <span className="font-semibold text-left">{lesson.title}</span>
                  </div>
                  {expandedLesson === index ? (
                    <ChevronUp className="text-gray-400" size={20} />
                  ) : (
                    <ChevronDown className="text-gray-400" size={20} />
                  )}
                </button>

                {expandedLesson === index && (
                  <div className="px-6 pb-6 border-t border-gray-100">
                    <p className="text-gray-700 mb-4 mt-4">{lesson.content}</p>

                    <div className="mb-4">
                      <h4 className="font-semibold mb-2">Examples:</h4>
                      <ul className="space-y-2">
                        {lesson.examples.map((example, i) => (
                          <li key={i} className="flex items-start gap-2 text-gray-600">
                            <span className="text-blue-600 mt-1">→</span>
                            <span>{example}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {lesson.tips && lesson.tips.length > 0 && (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 className="font-semibold mb-2 text-blue-900">Tips:</h4>
                        <ul className="space-y-1">
                          {lesson.tips.map((tip, i) => (
                            <li key={i} className="flex items-start gap-2 text-blue-800 text-sm">
                              <span className="mt-1">💡</span>
                              <span>{tip}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-600">
            Complete each level before moving to the next for best results. 
            Practice regularly with the interactive simulator and exercises.
          </p>
        </div>
      </div>
    </section>
  );
}
