export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white">
              A
            </div>
            <span className="font-semibold">Abacus Academy</span>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-sm">
              © {currentYear} Abacus Academy. Educational Project.
            </p>
            <p className="text-sm text-gray-400 mt-1">
              Empowering minds through traditional wisdom and modern technology.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
