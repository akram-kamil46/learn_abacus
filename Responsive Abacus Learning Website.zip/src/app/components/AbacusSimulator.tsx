import { useState, useEffect } from "react";
import { RotateCcw, Plus, Minus } from "lucide-react";

interface ColumnState {
  heaven: number; // 0 or 1
  earth: number; // 0 to 4
}

export function AbacusSimulator() {
  const [columns, setColumns] = useState<ColumnState[]>(
    Array(7).fill(null).map(() => ({ heaven: 0, earth: 0 }))
  );
  const [displayValue, setDisplayValue] = useState(0);
  const [operationMode, setOperationMode] = useState<"add" | "subtract" | null>(null);
  const [operand, setOperand] = useState("");
  const [result, setResult] = useState<string>("");

  // Calculate display value from column states
  useEffect(() => {
    let value = 0;
    for (let i = 0; i < columns.length; i++) {
      const placeValue = Math.pow(10, columns.length - 1 - i);
      const columnValue = columns[i].heaven * 5 + columns[i].earth;
      value += columnValue * placeValue;
    }
    setDisplayValue(value);
  }, [columns]);

  const resetAbacus = () => {
    setColumns(Array(7).fill(null).map(() => ({ heaven: 0, earth: 0 })));
    setOperationMode(null);
    setOperand("");
    setResult("");
  };

  const toggleHeavenBead = (colIndex: number) => {
    const newColumns = [...columns];
    newColumns[colIndex] = {
      ...newColumns[colIndex],
      heaven: newColumns[colIndex].heaven === 0 ? 1 : 0,
    };
    setColumns(newColumns);
  };

  const incrementEarthBead = (colIndex: number) => {
    const newColumns = [...columns];
    if (newColumns[colIndex].earth < 4) {
      newColumns[colIndex] = {
        ...newColumns[colIndex],
        earth: newColumns[colIndex].earth + 1,
      };
      setColumns(newColumns);
    }
  };

  const decrementEarthBead = (colIndex: number) => {
    const newColumns = [...columns];
    if (newColumns[colIndex].earth > 0) {
      newColumns[colIndex] = {
        ...newColumns[colIndex],
        earth: newColumns[colIndex].earth - 1,
      };
      setColumns(newColumns);
    }
  };

  const setNumber = (num: number) => {
    const numStr = num.toString().padStart(columns.length, '0');
    const newColumns = numStr.split('').map(digit => {
      const d = parseInt(digit);
      return {
        heaven: d >= 5 ? 1 : 0,
        earth: d >= 5 ? d - 5 : d,
      };
    });
    setColumns(newColumns);
  };

  const performOperation = () => {
    if (!operand || !operationMode) return;
    
    const num = parseInt(operand);
    if (isNaN(num)) return;

    let newValue = displayValue;
    if (operationMode === "add") {
      newValue = displayValue + num;
      setResult(`${displayValue} + ${num} = ${newValue}`);
    } else if (operationMode === "subtract") {
      newValue = displayValue - num;
      setResult(`${displayValue} - ${num} = ${newValue}`);
    }

    if (newValue >= 0 && newValue < Math.pow(10, columns.length)) {
      setNumber(newValue);
    }
    
    setOperand("");
    setOperationMode(null);
  };

  const startOperation = (mode: "add" | "subtract") => {
    setOperationMode(mode);
    setOperand("");
    setResult("");
  };

  return (
    <section id="simulator" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">Interactive Abacus Simulator</h2>
        <p className="text-lg text-gray-600 mb-12 text-center max-w-3xl mx-auto">
          Practice moving beads and performing calculations. Click heaven beads to toggle them, 
          and click earth beads to move them up or down. Works on both desktop and mobile devices.
        </p>

        <div className="max-w-5xl mx-auto">
          {/* Display */}
          <div className="bg-gray-900 text-white rounded-t-lg p-6">
            <div className="text-center mb-4">
              <div className="text-5xl md:text-6xl font-mono mb-2">{displayValue}</div>
              {result && (
                <div className="text-green-400 text-lg">{result}</div>
              )}
            </div>
          </div>

          {/* Abacus Frame */}
          <div className="bg-gradient-to-b from-amber-700 to-amber-800 p-4 md:p-8 rounded-b-lg border-4 border-amber-900">
            <div className="bg-amber-100 rounded-lg p-4 md:p-6">
              {/* Column Labels */}
              <div className="flex justify-around mb-2">
                {['1M', '100K', '10K', '1K', '100', '10', '1'].map((label, i) => (
                  <div key={i} className="text-center text-xs text-gray-600 w-12 md:w-16">
                    {label}
                  </div>
                ))}
              </div>

              {/* Abacus Columns */}
              <div className="flex justify-around gap-2 md:gap-4">
                {columns.map((col, colIndex) => (
                  <div key={colIndex} className="flex flex-col items-center">
                    {/* Heaven Section */}
                    <div className="relative h-20 md:h-24 w-12 md:w-16 border-b-4 border-gray-800 flex items-start justify-center py-2">
                      <button
                        onClick={() => toggleHeavenBead(colIndex)}
                        className={`w-8 h-8 md:w-10 md:h-10 rounded-full shadow-lg transition-all transform ${
                          col.heaven === 1
                            ? 'bg-red-500 translate-y-8 md:translate-y-10'
                            : 'bg-red-400 translate-y-0'
                        } hover:scale-110 active:scale-95`}
                        aria-label={`Toggle heaven bead column ${colIndex + 1}`}
                      />
                      {/* Rod */}
                      <div className="absolute top-0 bottom-0 w-1 bg-gray-700" style={{ zIndex: -1 }}></div>
                    </div>

                    {/* Earth Section */}
                    <div className="relative h-32 md:h-40 w-12 md:w-16 flex flex-col items-center justify-end py-2 gap-1">
                      {/* Rod */}
                      <div className="absolute top-0 bottom-0 w-1 bg-gray-700" style={{ zIndex: -1 }}></div>
                      
                      {/* Earth Beads */}
                      <div className="flex flex-col-reverse gap-1">
                        {[0, 1, 2, 3].map((beadIndex) => (
                          <button
                            key={beadIndex}
                            onClick={() => {
                              if (beadIndex < col.earth) {
                                decrementEarthBead(colIndex);
                              } else {
                                incrementEarthBead(colIndex);
                              }
                            }}
                            className={`w-8 h-8 md:w-10 md:h-10 rounded-full shadow-lg transition-all ${
                              beadIndex < col.earth
                                ? 'bg-blue-500'
                                : 'bg-blue-300'
                            } hover:scale-110 active:scale-95`}
                            aria-label={`Earth bead ${beadIndex + 1} column ${colIndex + 1}`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="mt-8 bg-gray-50 rounded-lg border border-gray-200 p-6">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <button
                onClick={resetAbacus}
                className="flex-1 flex items-center justify-center gap-2 bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors"
              >
                <RotateCcw size={20} />
                Reset
              </button>
              <button
                onClick={() => startOperation("add")}
                className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
              >
                <Plus size={20} />
                Add
              </button>
              <button
                onClick={() => startOperation("subtract")}
                className="flex-1 flex items-center justify-center gap-2 bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition-colors"
              >
                <Minus size={20} />
                Subtract
              </button>
            </div>

            {operationMode && (
              <div className="flex gap-2">
                <input
                  type="number"
                  value={operand}
                  onChange={(e) => setOperand(e.target.value)}
                  placeholder={`Enter number to ${operationMode}`}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      performOperation();
                    }
                  }}
                />
                <button
                  onClick={performOperation}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Calculate
                </button>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-lg mb-3">How to Use:</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Heaven beads (red):</strong> Click to toggle between 0 and 5</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Earth beads (blue):</strong> Click to move up/down (each represents 1)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Operations:</strong> Click Add or Subtract, enter a number, and press Calculate</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Reset:</strong> Returns all beads to zero position</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
