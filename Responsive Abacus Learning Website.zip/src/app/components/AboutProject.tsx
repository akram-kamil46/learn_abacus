import { Target, Book, Users } from "lucide-react";

export function AboutProject() {
  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl mb-6 text-center">About This Project</h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg border border-gray-200 p-8 mb-8">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Target className="text-blue-600" size={24} />
              </div>
              <div>
                <h3 className="text-xl mb-2">Our Mission</h3>
                <p className="text-gray-600">
                  To make abacus learning accessible, engaging, and effective for learners worldwide. 
                  We believe that mental arithmetic skills developed through abacus training provide 
                  lifelong benefits that extend far beyond mathematics.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Book className="text-blue-600" size={24} />
              </div>
              <div>
                <h3 className="text-xl mb-2">Educational Purpose</h3>
                <p className="text-gray-600">
                  This platform was developed as an educational project to demonstrate how traditional 
                  learning tools can be effectively integrated with modern web technology. Our goal is 
                  to preserve and promote this ancient calculating method while making it relevant for 
                  today's digital learners.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Users className="text-blue-600" size={24} />
              </div>
              <div>
                <h3 className="text-xl mb-2">Who We Serve</h3>
                <p className="text-gray-600">
                  Designed for students, parents, and educators, this platform provides structured 
                  learning paths, interactive tools, and comprehensive resources. Whether you're 
                  introducing abacus to young learners or reinforcing advanced techniques, our 
                  materials support every stage of the learning journey.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-xl mb-3">Future Development</h3>
            <p className="text-gray-700 mb-4">
              We are continuously working to enhance this platform with new features:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Advanced practice modes with adaptive difficulty</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Progress tracking and performance analytics</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Video tutorial library with expert demonstrations</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Community features for learners to share experiences</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
