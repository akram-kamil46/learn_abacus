import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { AboutAbacus } from "./components/AboutAbacus";
import { AbacusStructure } from "./components/AbacusStructure";
import { AbacusSimulator } from "./components/AbacusSimulator";
import { LearningModules } from "./components/LearningModules";
import { PracticeExercises } from "./components/PracticeExercises";
import { Benefits } from "./components/Benefits";
import { TargetAudience } from "./components/TargetAudience";
import { Resources } from "./components/Resources";
import { AboutProject } from "./components/AboutProject";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <AboutAbacus />
        <AbacusStructure />
        <AbacusSimulator />
        <LearningModules />
        <PracticeExercises />
        <Benefits />
        <TargetAudience />
        <Resources />
        <AboutProject />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
